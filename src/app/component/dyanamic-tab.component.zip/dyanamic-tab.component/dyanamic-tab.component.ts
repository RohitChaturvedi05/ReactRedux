import { Component, Input, Output, EventEmitter, OnInit, OnChanges, SimpleChanges, ElementRef, Renderer } from '@angular/core';
import { Http } from '@angular/http';



@Component(
    {
        selector: "dyanamic-table",
        templateUrl: "./dyanamic-tab.component.html",
        styleUrls: ["./dyanamic-tab.component.css"]
    }
)
export class DyanamicTableComponent implements OnInit, OnChanges {
    public empData = [];

    constructor(private _http: Http, private _elRef: ElementRef, public renderer: Renderer) {
        
        this.renderer.setElementStyle(this._elRef.nativeElement, 'width', '100%');
        this.renderer.setElementStyle(this._elRef.nativeElement, 'float', 'left');


    }
    ngOnInit() {
        this.empData = this.getData();
    }
    ngOnChanges(simpleChanges: SimpleChanges) {
    }

    getData() {
        return [
            {
                "userId": "rirani",
                "jobTitleName": "Developer",
                "firstName": "Romin",
                "lastName": "Irani",
                "preferredFullName": "Romin Irani",
                "employeeCode": "E1",
                "region": "CA",
                "phoneNumber": "408-1234567",
                "emailAddress": "romin.k.irani@gmail.com"
            },
            {
                "userId": "nirani",
                "jobTitleName": "Developer",
                "firstName": "Neil",
                "lastName": "Irani",
                "preferredFullName": "Neil Irani",
                "employeeCode": "E2",
                "region": "CA",
                "phoneNumber": "408-1111111",
                "emailAddress": "neilrirani@gmail.com"
            },
            {
                "userId": "thanks",
                "jobTitleName": "Program Directory",
                "firstName": "Tom",
                "lastName": "Hanks",
                "preferredFullName": "Tom Hanks",
                "employeeCode": "E3",
                "region": "CA",
                "phoneNumber": "408-2222222",
                "emailAddress": "tomhanks@gmail.com"
            },
            {
                "userId": "thanks",
                "jobTitleName": "Program Directory",
                "firstName": "Tom",
                "lastName": "Hanks",
                "preferredFullName": "Tom Hanks",
                "employeeCode": "E3",
                "region": "CA",
                "phoneNumber": "408-2222222",
                "emailAddress": "tomhanks@gmail.com"
            },
            {
                "userId": "thanks44",
                "jobTitleName": "Program Directory",
                "firstName": "Tom",
                "lastName": "Hanks",
                "preferredFullName": "Tom Hanks",
                "employeeCode": "E3",
                "region": "CA",
                "phoneNumber": "408-2222222",
                "emailAddress": "tomhanksaa@gmail.com"
            },
            {
                "userId": "thanksq",
                "jobTitleName": "Program Directory",
                "firstName": "Tom",
                "lastName": "Hanks",
                "preferredFullName": "Tom Hanks",
                "employeeCode": "E3",
                "region": "CA",
                "phoneNumber": "408-2222222",
                "emailAddress": "tomhanks121@gmail.com"
            },
            {
                "userId": "thanks",
                "jobTitleName": "Program Directory",
                "firstName": "Tom",
                "lastName": "Hanks",
                "preferredFullName": "Tom Hanks",
                "employeeCode": "E3",
                "region": "CA",
                "phoneNumber": "408-2222222",
                "emailAddress": "tomhanks@gmail.com"
            },
            {
                "userId": "thanks",
                "jobTitleName": "Program Directory",
                "firstName": "Tom",
                "lastName": "Hanks",
                "preferredFullName": "Tom Hanks",
                "employeeCode": "E3",
                "region": "CA",
                "phoneNumber": "408-2222222",
                "emailAddress": "tomhanks@gmail.com"
            },
            {
                "userId": "thanks",
                "jobTitleName": "Program Directory",
                "firstName": "Tom",
                "lastName": "Hanks",
                "preferredFullName": "Tom Hanks",
                "employeeCode": "E3",
                "region": "CA",
                "phoneNumber": "408-2222222",
                "emailAddress": "tomhanks@gmail.com"
            },
            {
                "userId": "thanks",
                "jobTitleName": "Program Directory",
                "firstName": "Tom",
                "lastName": "Hanks",
                "preferredFullName": "Tom Hanks",
                "employeeCode": "E3",
                "region": "CA",
                "phoneNumber": "408-2222222",
                "emailAddress": "tomhanks@gmail.com"
            },
            {
                "userId": "thanks",
                "jobTitleName": "Program Directory",
                "firstName": "Tom",
                "lastName": "Hanks",
                "preferredFullName": "Tom Hanks",
                "employeeCode": "E3",
                "region": "CA",
                "phoneNumber": "408-2222222",
                "emailAddress": "tomhanks@gmail.com"
            }
        ];
    }
    generateArray(obj) {
        return Object.keys(obj).map((key) => { return obj[key] });
    }
    getColumns(obj) {
        obj = obj.length > 0 ? obj[0] : obj;
        return Object.keys(obj);
    }
    colWidth() {
        return (100 / this.empData.length) + "%";
    }
}