import { NgModule } from '@angular/core';
import { DyanamicTableComponent } from './dyanamic-tab.component';
import { GroupByPipe, MapToIterable } from './custom.pipes'
import { BrowserModule } from '@angular/platform-browser';

@NgModule({
    declarations: [
        DyanamicTableComponent,
        GroupByPipe,
        MapToIterable
    ],
    imports: [
        BrowserModule
    ],
    exports: [
        DyanamicTableComponent,
        GroupByPipe,
        MapToIterable
    ]
})
export class DyanamicTableModule { }